<?php
/**
 * Plugin Name: First Plugin
 * Description: This is description of the first plugin
 * Version: 1.0.0
 * Author: RJ Danish
 * Author URI: https://google.com
 */

//  just for security reasons someone can not directly access the files of this plugin
if(!defined('ABSPATH')){
    header('location: /');
    // die('You can not access');
}
function my_plugin_activation(){
    
    global $wpdb, $table_prefix;

    $wp_emp = $table_prefix.'emp';
    // create table
    $query = "CREATE TABLE IF NOT EXISTS `$wp_emp` ( `id` INT NOT NULL AUTO_INCREMENT , `name` VARCHAR(255) NOT NULL , `email` VARCHAR(255) NOT NULL , `status` BOOLEAN NOT NULL , PRIMARY KEY (`id`)) ENGINE = MyISAM;";

    $wpdb->query($query);

    // insert data into table first traditional method
    // $query = "INSERT INTO `$wp_emp` (`name`, `email`, `status`) VALUES ('Muhammad Danish', 'danish@gmail.com', 1);";  
    // Proper wordpress way to insert the record into the database
    // $wpdb->query($query);

    $data = array(
        'name' => 'Noman',
        'email' => 'noman@gmail.com',
        'status' => 1
    );

    $wpdb->insert($wp_emp, $data);

}
register_activation_hook(__FILE__, 'my_plugin_activation');

function my_plugin_deactivation(){

    global $wpdb, $table_prefix;

    $wp_emp = $table_prefix.'emp';
    
    $query = "TRUNCATE `$wp_emp`";

    $wpdb->query($query);
}
register_deactivation_hook(__FILE__, 'my_plugin_deactivation');

function my_shortcode(){
    return 'Function call';
}
add_shortcode('my-sc', 'my_shortcode');